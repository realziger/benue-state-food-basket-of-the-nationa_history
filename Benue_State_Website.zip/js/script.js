const lgas = [
"Ado","Agatu","Apa","Buruku","Gbajimba (Guma)","Gwer","Gwer West",
"Katsina-Ala","Konshisha","Kwande","Logo","Makurdi","Obi","Ogbadibo",
"Ohimini","Oju","Okpokwu","Otukpo","Tarka","Ukum","Ushongo",
"Vandeikya","Apa"
];

// The list above is intentionally a starter list.
// Verify the official 23-LGA list before publishing.

const governors = [
["Abdullahi Shelleng","Mar 1976","Jul 1978","Military"],
["Adebayo Lawal","Jul 1978","Oct 1979","Military"],
["Aper Aku","Oct 1979","Dec 1983","NPN"],
["John Kpera","Jan 1984","Aug 1985","Military"],
["Jonah David Jang","Aug 1985","Aug 1986","Military"],
["Yohanna Madaki","Aug 1986","Sep 1986","Military"],
["Ishaya Bakut","Sep 1986","1987","Military"],
["Idris Garba","1987","1987","Military"],
["Fidelis Makka","Dec 1987","Jan 1992","Military"],
["Moses Adasu","Jan 1992","Nov 1993","SDP"],
["Joshua O. Obademi","Dec 1993","Aug 1996","Administrator"],
["Aminu Isa Kontagora","Aug 1996","Aug 1998","Administrator"],
["Dominic Oneya","Aug 1998","May 1999","Administrator"],
["George Akume","May 1999","May 2007","PDP"],
["Gabriel Suswam","May 2007","May 2015","PDP"],
["Samuel Ortom","May 2015","May 2023","PDP"],
["Hyacinth Alia","May 2023","Present","APC"]
];

document.getElementById("lga-list").innerHTML =
  "<ul>" + lgas.map(x => `<li>${x}</li>`).join("") + "</ul>";

document.getElementById("governor-list").innerHTML =
  "<table><thead><tr><th>Name</th><th>Started</th><th>Ended</th><th>Type/Party</th></tr></thead><tbody>" +
  governors.map(g => `<tr><td>${g[0]}</td><td>${g[1]}</td><td>${g[2]}</td><td>${g[3]}</td></tr>`).join("") +
  "</tbody></table>";
